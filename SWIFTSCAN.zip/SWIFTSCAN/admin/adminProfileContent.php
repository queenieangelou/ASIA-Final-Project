<!-- Admin Profile Tab Content -->
<div class="tab-pane fade" id="adminProfileContent">
        <h2>Admin Profile</h2>
        <!-- Add admin profile information here -->
        <button id="logoutBtn" class="btn btn-primary" onclick="logout()">Logout</button>
    </div>